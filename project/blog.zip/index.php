<?php
	define('APP_NAME','blog');
	define('APP_PATH','./blog/');
	define('APP_DEBUG',true);
	define('BASEURL',__DIR__);
	require('./ThinkPHP/ThinkPHP.php');
?>