<?php
namespace Think\Session\Driver;


class Redis{

	private $redis;

	public function execute(){
		session_set_save_handler(
			array(&$this,'open'),
			array(&$this,'close'),
			array(&$this,'read'),
			array(&$this,'write'),
			array(&$this,'destroy'),
			array(&$this,'gc')
		);
	}

	public function open($path,$name){
		$this->redis = new Redis();
		return $this->redis->connect(C('REDIS_HOST'),C('REDIS_PORT'));
	}
}