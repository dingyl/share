<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script src="/test/kindeditor/kindeditor-all.js"></script>
    <link rel="stylesheet" href="/test/kindeditor/themes/default/default.css">


    <script>
        KindEditor.ready(function(K) {
            var editor = K.create('textarea[name="articlecontent"]', {
                cssPath : '/test/kindeditor/plugins/code/prettify.css',
                uploadJson : "<?php echo U('article/imgupload');?>"
            });
            prettyPrint();
        });

        $(function(){
            $("form").submit(function(){
                var articletitle = $("input[name='articletitle']").val();
                if($.trim(articletitle)==''){
                    alert("文章标题不能为空!");
                    return false;
                }
            });
        })
    </script>

</head>
<body>
	
    <br>
    <div class="container">
        <form class="form-inline" action="<?php echo U('article/edit');?>" method="post" class="form">
            <div class="row">
                <label for="articletitle">文章标题:</label>
                <input type="text" name="articletitle" value="<?php echo ($article['articletitle']); ?>">
                <label for="cateid">文章分类:</label>

                <?php if(!empty($cate)): ?><select name="cateid" id="">
                        <?php if(is_array($cate)): foreach($cate as $k=>$v): ?><option value="<?php echo ($v['cateid']); ?>" <?php if($v['cateid'] == $article['articleid']): ?>selected<?php endif; ?> <?php if($v['level'] < 2): ?>disabled<?php endif; ?> ><?php echo str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$v['level']).'|--'.$v['catename'];?></option><?php endforeach; endif; ?>
                    </select><?php endif; ?>
                <input type="hidden" name="articleid" value="<?php echo ($article['articleid']); ?>">
            </div>
            <br>
            <div class="row">
                <textarea name="articlecontent" style="width:700px;height:500px;visibility:hidden;"><?php echo ($article['articlecontent']); ?></textarea>
            </div>

            <div class="row">
                <input type="submit" value="保存" class="btn-primary">
            </div>
        </form>
    </div>

</body>
</html>