<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <link rel="stylesheet" href="/test/bootstrap/css/bootstrap.css">
    <script src="/test/public/blog/js/jquery-1.7.2.min.js"></script>
    <script src="/test/bootstrap/js/bootstrap.js"></script>
    <title>login</title>
    <style>
        .login{
            border: 1px solid #ccc;
            width: 500px;
            margin: 100px auto;
            border-radius: 4px;
            padding: 20px 0;
            box-shadow: 1px 1px 1px #ccc;
        }
    </style>

    <script>
        $(function(){
            $("#vcode").click(function(){
                var src = $(this).attr('src');
                $(this).attr('src',src+"?time="+Math.random());
            });

            $("form").submit(function(){
                var username = $.trim($("input[name='username']").val());
                var passwd = $.trim($("input[name='passwd']").val());
                var verifycode = $.trim($("input[name='verifycode']").val());
                if(username==''){
                    alert("用户名不能为空!");
                    return false;
                }
                if(passwd==''){
                    alert("密码不能为空!");
                    return false;
                }
                if(verifycode==''){
                    alert("验证码不能为空!");
                    return false;
                }
            });
        });
    </script>
</head>
<body>
<div class="login">
    <form action="<?php echo U('blog/login');?>" method="post" class="form-horizontal">
        <div class="control-group">
            <label class="control-label" for="inputEmail">用户名:</label>
            <div class="controls">
                <input type="text" name="username" id="inputEmail" placeholder="用户名">
            </div>
        </div>
        <div class="control-group">
            <label class="control-label" for="inputPassword">密码:</label>
            <div class="controls">
                <input type="password" name="passwd" id="inputPassword" placeholder="密码">
            </div>
        </div>
        <div class="control-group">
            <label class="control-label" for="inputPassword">验证码:</label>
            <div class="controls">
                <input style="width:100px;" type="text" name="verifycode" id="inputPassword" placeholder="验证码">
                <img id="vcode" style="width:100px;cursor:pointer;" src="<?php echo U('blog/verify');?>" alt="">
            </div>
        </div>
        <div class="control-group">
            <div class="controls">
                <button type="submit" class="btn">登 陆</button>
                <a class="btn" href="<?php echo U('blog/register');?>">去注册</a>
            </div>
        </div>
    </form>
</div>
</body>
</html>