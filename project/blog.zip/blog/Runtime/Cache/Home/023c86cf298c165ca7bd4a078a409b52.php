<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="/test/public/blog/Css/common.css" />
    <script type="text/JavaScript" src='/test/public/blog/Js/jquery-1.7.2.min.js'></script>
    <script type="text/JavaScript" src='/test/public/blog/Js/common.js'></script>
    
    <link rel="stylesheet" href="/test/public/blog/Css/index.css" />

</head>
<body>
    <!--头部-->
    <div class='top-list-wrap'>
        <div class='top-list'>
            <ul class='l-list'>
                <li><a href="http://study.163.com/" target='_blank'>网易云课堂</a></li>
                <li><a href="http://www.imooc.com/" target='_blank'>慕课网</a></li>
            </ul>
            <ul class='r-list'>
                <?php if(!empty(session('islogined'))): ?><li><a href="javascript:;">欢迎[ <?php echo session('username');?> ]登陆</a> </li>
                    <li><img style="height:20px;" src="/test/upload/avater/<?php echo empty(session('avater'))?'default.jpg':session('avater');;?>" alt=""></li><?php endif; ?>
                <li><a href="<?php echo U('index/index');?>" target='_blank'>后台</a></li>
                <?php if(empty(session('islogined'))): ?><li>
                        <a href="<?php echo U('blog/login');?>" target='_blank'>登陆</a>
                    </li>
                    <?php else: ?>
                    <li><a href="<?php echo U('blog/updatepwd',array('userid'=>session('userid')));?>" target='_self'>修改密码</a></li>
                    <li><a href="<?php echo U('blog/editinfo',array('userid'=>session('userid')));?>" target='_self'>修改信息</a></li>
                    <li><a href="<?php echo U('blog/loginout');?>" target='_self'>退出登陆</a></li><?php endif; ?>
            </ul>
        </div>
    </div>


    <div class='top-search-wrap'>
        <div class='top-search'>
            <div class='search-wrap'>
                <form action="<?php echo U('blog/index');?>" method='post'>
                    <input type="text" name='keyword' class='search-content'/>
                    <input type="submit" name='search' value='搜索'/>
                </form>
            </div>
        </div>
    </div>


    <div class='top-nav-wrap'>
        <ul class='nav-lv1'>
            <li class='nav-lv1-li'>
                <a href="<?php echo U('blog/index');?>" class='top-cate'>博客首页</a>
            </li>

            <?php if(!empty($catelist)): if(is_array($catelist)): foreach($catelist as $k=>$v): ?><li class='nav-lv1-li'>
                        <a href="javascript:;" class='top-cate'><?php echo ($v['catename']); ?></a>
                        <?php if(!empty($v['child'])): ?><ul>
                                <?php if(is_array($v['child'])): foreach($v['child'] as $ok=>$ov): ?><li><a href="<?php echo U('blog/catebloglist',array('cateid'=>$ov['cateid']));?>"><?php echo ($ov['catename']); ?></a></li><?php endforeach; endif; ?>
                            </ul><?php endif; ?>
                    </li><?php endforeach; endif; endif; ?>
        </ul>
    </div>
    <div class='main'>
        <div class="wrapleft">
            
    <div class='main-left'>
        <p>我的博文</p>
        <?php if(!empty($subcatelist)): if(is_array($subcatelist)): foreach($subcatelist as $k=>$v): ?><dl>
                    <dt><?php echo ($v['catename']); ?><a href="<?php echo U('blog/bloglist',array('cateid'=>$v['cateid']));?>">更多>></a></dt>
                    <?php if(!empty($v['articlelist'])): if(is_array($v['articlelist'])): foreach($v['articlelist'] as $ok=>$ov): ?><dd>
                                <a href="<?php echo U('blog/blogshow',array('articleid'=>$ov['articleid']));?>"><?php echo ($ov['articletitle']); ?></a>
                                <span><?php echo date('Y-m-d',$ov['createtime']);?></span>
                            </dd><?php endforeach; endif; endif; ?>
                </dl><?php endforeach; endif; endif; ?>
    </div>

        </div>

        <div class='main-right'>
            <dl>
                <dt>热门博文</dt>
                <?php if(!empty($hotarticle)): if(is_array($hotarticle)): foreach($hotarticle as $k=>$v): ?><dd>
                            <a href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                            <span>(<?php echo ($v['clickcount']); ?>)</span>
                        </dd><?php endforeach; endif; endif; ?>
            </dl>

            <dl>
                <dt>最新布发</dt>
                <?php if(!empty($newarticle)): if(is_array($newarticle)): foreach($newarticle as $k=>$v): ?><dd>
                            <a href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                            <span>(<?php echo ($v['clickcount']); ?>)</span>
                        </dd><?php endforeach; endif; endif; ?>
            </dl>

            <dl>
                <dt>友情连接</dt>
                <dd>
                    <a href="http://www.imooc.com/" target='_blank'>慕课网</a>
                </dd>
                <dd>
                    <a href="http://cn.bing.com/" target='_blank'>必应搜索</a>
                </dd>
                <dd>
                    <a href="http://study.163.com/" target='_blank'>网易云课堂</a>
                </dd>
            </dl>
        </div>
    </div>
    <div class="bottom">
        <div></div>
    </div>
</body>
</html>