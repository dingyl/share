<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="/pblog/public/blog/Css/common.css" />
    <script type="text/JavaScript" src='/pblog/public/blog/Js/jquery-1.7.2.min.js'></script>
    <script type="text/JavaScript" src='/pblog/public/blog/Js/common.js'></script>
    
    <link rel="stylesheet" href="/pblog/public/blog/Css/show.css" />
   <!-- <link rel="stylesheet" href="/pblog/public/blog/Css/list.css" />-->
    <style>
        .main .main-left{
            height: 840px;
            overflow: hidden;
            position: relative;
        }
        .content .overlay *{
            margin:0;
            padding:0
        }
        .content .overlay{
            position:absolute;
            bottom:0;
            color:#3377c6;
            border:1px solid #3377c6;
            left: 50%;
            margin-left: -50px;
        }
        .content .overlay span{
            display: block;
            line-height: 40px;
            cursor:pointer;
            width: 100px;
            background: #ccc;
            opacity: 0.7;
            text-align: center;
        }

        div.updown {
            width: 26px;
            position: fixed;
            border: 1px solid #;
            z-index: 4;
            bottom: 100px;
            right: 40px;
            padding: 2px;
            background: #ccc;
            border-radius: 1px;
            box-shadow: 1px 1px 1px #ccc;
            cursor: pointer;
        }

        .comment{
            float:left;
            width:630px;
        }

        .box{
            padding: 30px 16px;
            background: #f9f9f9;
            border-radius: 2px;
            margin: 10px 0;
            border: 1px solid #ccc;
        }

        .box textarea{
            resize:none;
            width:590px;
            height:100px;
            margin:0 auto;
            display:block;
            border: 1px solid #ccc;
            font-size: 12px;
            font-family: console;
        }
        a.replycomment{
            cursor: pointer;
            color: red;
        }
    </style>
    <script>
        $(function(){
            $(".overlay").click(function(){
                $(this).hide();
                $(".main-left").css('height','auto');
            });

            $(".updown").click(function(){
                document.body.scrollTop = document.documentElement.scrollTop = 0;
            });

            $("#comment").click(function(){
                var text = $.trim($("textarea").val());
                var replyaid = $("input[name='replyaid']").val();
                var replypid = $("input[name='replypid']").val();
                var userid = $("input[name='userid']").val();
                var level = $("input[name='level']").val();

                if(userid==''){
                    alert("请先登陆再来评论!");
                }else{
                    if(text==''){
                        alert("评论内容不能为空!");
                    }else{
                        if(replypid==''){
                            replypid=0;
                        }
                        $.ajax({
                            url:"<?php echo U('blog/comment');?>",
                            data:"articleid="+replyaid+"&level="+level+"&uid="+userid+"&commentext="+text+"&replyid="+replypid,
                            type:"post",
                            dataType:"json",
                            success:function(data){
                                alert(data.message);
                                window.location.reload();
                            }
                        });
                    }
                }
            });

            $(".replycomment").click(function(){
                $("input[name='replypid']").val($(this).attr('value'));
                $("input[name='level']").val($(this).attr('level'));
                $("textarea").attr('placeholder',"回复"+$(this).attr('uname')+":");
                $("textarea").val('');
            });
        })
    </script>

</head>
<body>
    <!--头部-->
    <div class='top-list-wrap'>
        <div class='top-list'>
            <ul class='l-list'>
                <li><a href="http://study.163.com/" target='_blank'>网易云课堂</a></li>
                <li><a href="http://www.imooc.com/" target='_blank'>慕课网</a></li>
            </ul>
            <ul class='r-list'>
                <?php if(!empty(session('islogined'))): ?><li><a href="javascript:;">欢迎[ <?php echo session('username');?> ]登陆</a> </li>
                    <li><img style="height:20px;" src="/pblog/upload/avater/<?php echo empty(session('avater'))?'default.jpg':session('avater');;?>" alt=""></li><?php endif; ?>
                <li><a href="<?php echo U('index/index');?>" target='_blank'>后台</a></li>
                <?php if(empty(session('islogined'))): ?><li>
                        <a href="<?php echo U('blog/login');?>" target='_blank'>登陆</a>
                    </li>
                    <?php else: ?>
                    <li><a href="<?php echo U('blog/updatepwd',array('userid'=>session('userid')));?>" target='_self'>修改密码</a></li>
                    <li><a href="<?php echo U('blog/editinfo',array('userid'=>session('userid')));?>" target='_self'>修改信息</a></li>
                    <li><a href="<?php echo U('blog/loginout');?>" target='_self'>退出登陆</a></li><?php endif; ?>
            </ul>
        </div>
    </div>


    <div class='top-search-wrap'>
        <div class='top-search'>
            <div class='search-wrap'>
                <form action="<?php echo U('blog/index');?>" method='post'>
                    <input type="text" name='keyword' class='search-content'/>
                    <input type="submit" name='search' value='搜索'/>
                </form>
            </div>
        </div>
    </div>


    <div class='top-nav-wrap'>
        <ul class='nav-lv1'>
            <li class='nav-lv1-li'>
                <a href="<?php echo U('blog/index');?>" class='top-cate'>博客首页</a>
            </li>

            <?php if(!empty($catelist)): if(is_array($catelist)): foreach($catelist as $k=>$v): ?><li class='nav-lv1-li'>
                        <a href="javascript:;" class='top-cate'><?php echo ($v['catename']); ?></a>
                        <?php if(!empty($v['child'])): ?><ul>
                                <?php if(is_array($v['child'])): foreach($v['child'] as $ok=>$ov): ?><li><a href="<?php echo U('blog/catebloglist',array('cateid'=>$ov['cateid']));?>"><?php echo ($ov['catename']); ?></a></li><?php endforeach; endif; ?>
                            </ul><?php endif; ?>
                    </li><?php endforeach; endif; endif; ?>
        </ul>
    </div>
    <div class='main'>
        <div class="wrapleft">
            
    <div class="updown">回到顶部</div>
    <div class='main-left'>
        <div class='location'>
            <a href="<?php echo U('blog/index');?>">首页</a>>
            <a href="javascript:;"><?php echo ($firstcate['catename']); ?></a>>
            <a href="<?php echo U('blog/catebloglist',array('cateid'=>$secondcate['cateid']));?>"><?php echo ($secondcate['catename']); ?></a>>
            <a href="<?php echo U('blog/bloglist',array('cateid'=>$thirdcate['cateid']));?>"><?php echo ($thirdcate['catename']); ?></a>
        </div>
        <div class="title">
            <p><?php echo ($article['articletitle']); ?></p>
            <div>
                <span class='fl'>发布于：<?php echo date('Y-m-d H:i:s',$article['createtime']);?></span>
                <span class='fr'>已被阅读<?php echo ($article['clickcount']); ?>次</span>
            </div>
        </div>
        <div class='content'>
            <?php echo htmlspecialchars_decode($article['articlecontent']);?>
            <div class="overlay">
                <span>查看全部</span>
            </div>
        </div>
    </div>

    <div class="comment">
        <div class="box">
            <input type="hidden" name="replyaid" value="<?php echo ($article['articleid']); ?>">
            <input type="hidden" name="replypid" value="0">
            <input type="hidden" name="userid" value="<?php echo session('userid');?>">
            <input type="hidden" name="level" value="0">
            <textarea placeholder="我要评论" name="reply"></textarea>

            <div>
                <a id="comment" href="javascript:;">我来评论</a>
            </div>
        </div>

        <div class="commentlist">
            <dl>
                <dt>评论列表</dt>
                <?php if(!empty($comlist)): if(is_array($comlist)): foreach($comlist as $k=>$v): ?><dd class='info'>
                            <span style="color: #5461bd;text-indent:<?php echo ($v['level']*20+14); ?>px;" class='time'>用户:<?php echo ($v['username']); ?> &nbsp;&nbsp;<?php echo date('Y-m-d H:i:s',$v['createtime']);?><a
                                    class="replycomment" level="<?php echo ($v['level']); ?>" uname="<?php echo ($v['username']); ?>" value="<?php echo ($v['commentid']); ?>">回复此评论</a></span>
                        </dd>
                        <dd class='content'><p style="text-indent:<?php echo ($v['level']*20+40); ?>px;">评论:<?php echo ($v['commentext']); ?></p></dd><?php endforeach; endif; endif; ?>
            </dl>
        </div>
    </div>

        </div>

        <div class='main-right'>
            <dl>
                <dt>热门博文</dt>
                <?php if(!empty($hotarticle)): if(is_array($hotarticle)): foreach($hotarticle as $k=>$v): ?><dd>
                            <a href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                            <span>(<?php echo ($v['clickcount']); ?>)</span>
                        </dd><?php endforeach; endif; endif; ?>
            </dl>

            <dl>
                <dt>最新布发</dt>
                <?php if(!empty($newarticle)): if(is_array($newarticle)): foreach($newarticle as $k=>$v): ?><dd>
                            <a href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                            <span>(<?php echo ($v['clickcount']); ?>)</span>
                        </dd><?php endforeach; endif; endif; ?>
            </dl>

            <dl>
                <dt>友情连接</dt>
                <dd>
                    <a href="http://www.imooc.com/" target='_blank'>慕课网</a>
                </dd>
                <dd>
                    <a href="http://cn.bing.com/" target='_blank'>必应搜索</a>
                </dd>
                <dd>
                    <a href="http://study.163.com/" target='_blank'>网易云课堂</a>
                </dd>
            </dl>
        </div>
    </div>
    <div class="bottom">
        <div></div>
    </div>
</body>
</html>