<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        $(function(){
            $('.check').on('change',function(){
                $(this).parent().next('div').find("input").attr('checked',this.checked);
            });

            $("#submit").click(function(){
                var itemids = '';
                $(".items input:checked").each(function(){
                    itemids += $(this).val()+',';
                });
                $.ajax({
                    type: "POST",
                    url: "<?php echo U('role/grant');?>",
                    data: "roleid=<?php echo ($roleid); ?>&itemids="+itemids,
                    dataType:"json",
                    success: function(data){
                        alert(data.message);
                        window.location.reload();
                    }
                });
            });
        });
    </script>
    <style>
        .wrap div.app{
            border:1px solid #ccc;
            margin:4px 8px;
        }
        .wrap div.ctrl{
            background:#dee5fa;
            color:#6f9fd5;
            padding:10px;
            font-size:16px;
        }

        .wrap div span{margin:10px}
        .wrap div.items{
            color:#777;
            font-size:16px;
            overflow:hidden;
            padding:10px 0;
        }

        .wrap input{
            margin:-6px 2px;
        }
    </style>

</head>
<body>
	
    <div class="wrap">
        <div class="app">
            <div class="ctrl" style="color:#777">
                给[<?php echo ($rolename); ?>]角色配置权限:
            </div>
        </div>

        <?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><div class="app">
                    <div class="ctrl">
                        <strong><?php echo ($k); ?></strong>
                        <input type="checkbox" class="check">
                    </div>
                    <?php if(count($v) > 0): ?><div class="items">
                            <?php if(is_array($v)): foreach($v as $k=>$ov): ?><span>
                                    <?php if(!empty($ov['mark'])){echo $ov['mark'];}else{echo $ov['itemname'];}?>
                                    <input type="checkbox" value="<?php echo ($ov['itemid']); ?>" <?php if(in_array($ov['itemid'],$itemids)){echo 'checked';} ?> >
                                </span><?php endforeach; endif; ?>
                        </div><?php endif; ?>
                </div><?php endforeach; endif; endif; ?>
        <input type="hidden" value="<?php echo ($roleid); ?>" id="roleid">
        <div class="app">
            <div class="ctrl">
                <input type="button" id="submit" class="btn-primary" value="提交">
            </div>

        </div>
    </div>

</body>
</html>