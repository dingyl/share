<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="/pblog/public/blog/Css/common.css" />
    <script type="text/JavaScript" src='/pblog/public/blog/Js/jquery-1.7.2.min.js'></script>
    <script type="text/JavaScript" src='/pblog/public/blog/Js/common.js'></script>
    
    <link rel="stylesheet" href="/pblog/public/blog/Css/list.css" />
    <style>
        .main-left{background:#ffffff;padding: 10px;border-radius: 4px;box-shadow: 1px 1px 1px #888888}
        .row{overflow: hidden;line-height: 30px;}
        .row .left{color: #5461ad;float:left}
        .row .left:hover{text-decoration: underline;}
        .row .right{float:right;color:#999999}

        .pagination {
            margin: 20px 0;
        }

        .pagination ul {
            display: inline-block;
            *display: inline;
            margin-bottom: 0;
            margin-left: 0;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            border-radius: 4px;
            *zoom: 1;
            -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .pagination ul > li {
            display: inline;
        }

        .pagination ul > li > a,
        .pagination ul > li > span {
            float: left;
            padding: 4px 12px;
            line-height: 20px;
            text-decoration: none;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-left-width: 0;
        }

        .pagination ul > li > a:hover,
        .pagination ul > li > a:focus,
        .pagination ul > .active > a,
        .pagination ul > .active > span {
            background-color: #f5f5f5;
        }

        .pagination ul > .active > a,
        .pagination ul > .active > span {
            color: #999999;
            cursor: default;
        }

        .pagination ul > .disabled > span,
        .pagination ul > .disabled > a,
        .pagination ul > .disabled > a:hover,
        .pagination ul > .disabled > a:focus {
            color: #999999;
            cursor: default;
            background-color: transparent;
        }

        .pagination ul > li:first-child > a,
        .pagination ul > li:first-child > span {
            border-left-width: 1px;
            -webkit-border-bottom-left-radius: 4px;
            border-bottom-left-radius: 4px;
            -webkit-border-top-left-radius: 4px;
            border-top-left-radius: 4px;
            -moz-border-radius-bottomleft: 4px;
            -moz-border-radius-topleft: 4px;
        }

        .pagination ul > li:last-child > a,
        .pagination ul > li:last-child > span {
            -webkit-border-top-right-radius: 4px;
            border-top-right-radius: 4px;
            -webkit-border-bottom-right-radius: 4px;
            border-bottom-right-radius: 4px;
            -moz-border-radius-topright: 4px;
            -moz-border-radius-bottomright: 4px;
        }
    </style>

</head>
<body>
    <!--头部-->
    <div class='top-list-wrap'>
        <div class='top-list'>
            <ul class='l-list'>
                <li><a href="http://study.163.com/" target='_blank'>网易云课堂</a></li>
                <li><a href="http://www.imooc.com/" target='_blank'>慕课网</a></li>
            </ul>
            <ul class='r-list'>
                <?php if(!empty(session('islogined'))): ?><li><a href="javascript:;">欢迎[ <?php echo session('username');?> ]登陆</a> </li>
                    <li><img style="height:20px;" src="/pblog/upload/avater/<?php echo empty(session('avater'))?'default.jpg':session('avater');;?>" alt=""></li><?php endif; ?>
                <li><a href="<?php echo U('index/index');?>" target='_blank'>后台</a></li>
                <?php if(empty(session('islogined'))): ?><li>
                        <a href="<?php echo U('blog/login');?>" target='_blank'>登陆</a>
                    </li>
                    <?php else: ?>
                    <li><a href="<?php echo U('blog/updatepwd',array('userid'=>session('userid')));?>" target='_self'>修改密码</a></li>
                    <li><a href="<?php echo U('blog/editinfo',array('userid'=>session('userid')));?>" target='_self'>修改信息</a></li>
                    <li><a href="<?php echo U('blog/loginout');?>" target='_self'>退出登陆</a></li><?php endif; ?>
            </ul>
        </div>
    </div>


    <div class='top-search-wrap'>
        <div class='top-search'>
            <div class='search-wrap'>
                <form action="<?php echo U('blog/index');?>" method='post'>
                    <input type="text" name='keyword' class='search-content'/>
                    <input type="submit" name='search' value='搜索'/>
                </form>
            </div>
        </div>
    </div>


    <div class='top-nav-wrap'>
        <ul class='nav-lv1'>
            <li class='nav-lv1-li'>
                <a href="<?php echo U('blog/index');?>" class='top-cate'>博客首页</a>
            </li>

            <?php if(!empty($catelist)): if(is_array($catelist)): foreach($catelist as $k=>$v): ?><li class='nav-lv1-li'>
                        <a href="javascript:;" class='top-cate'><?php echo ($v['catename']); ?></a>
                        <?php if(!empty($v['child'])): ?><ul>
                                <?php if(is_array($v['child'])): foreach($v['child'] as $ok=>$ov): ?><li><a href="<?php echo U('blog/catebloglist',array('cateid'=>$ov['cateid']));?>"><?php echo ($ov['catename']); ?></a></li><?php endforeach; endif; ?>
                            </ul><?php endif; ?>
                    </li><?php endforeach; endif; endif; ?>
        </ul>
    </div>
    <div class='main'>
        <div class="wrapleft">
            
    <div class='main-left'>
        <?php if(!empty($articlelist)): if(is_array($articlelist)): foreach($articlelist as $k=>$v): ?><div class="row">
                    <a class="left" href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                    <span class="right"><?php echo date('Y/m/d',$v['createtime']);?> 点击：<?php echo ($v['clickcount']); ?></span>
                </div><?php endforeach; endif; endif; ?>
        <?php echo ($page); ?>
    </div>

        </div>

        <div class='main-right'>
            <dl>
                <dt>热门博文</dt>
                <?php if(!empty($hotarticle)): if(is_array($hotarticle)): foreach($hotarticle as $k=>$v): ?><dd>
                            <a href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                            <span>(<?php echo ($v['clickcount']); ?>)</span>
                        </dd><?php endforeach; endif; endif; ?>
            </dl>

            <dl>
                <dt>最新布发</dt>
                <?php if(!empty($newarticle)): if(is_array($newarticle)): foreach($newarticle as $k=>$v): ?><dd>
                            <a href="<?php echo U('blog/blogshow',array('articleid'=>$v['articleid']));?>"><?php echo ($v['articletitle']); ?></a>
                            <span>(<?php echo ($v['clickcount']); ?>)</span>
                        </dd><?php endforeach; endif; endif; ?>
            </dl>

            <dl>
                <dt>友情连接</dt>
                <dd>
                    <a href="http://www.imooc.com/" target='_blank'>慕课网</a>
                </dd>
                <dd>
                    <a href="http://cn.bing.com/" target='_blank'>必应搜索</a>
                </dd>
                <dd>
                    <a href="http://study.163.com/" target='_blank'>网易云课堂</a>
                </dd>
            </dl>
        </div>
    </div>
    <div class="bottom">
        <div></div>
    </div>
</body>
</html>