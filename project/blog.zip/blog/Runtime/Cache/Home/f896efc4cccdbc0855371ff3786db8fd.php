<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        function PreviewImage(imgFile)
        {
            var filextension=imgFile.value.substring(imgFile.value.lastIndexOf("."),imgFile.value.length);
            filextension=filextension.toLowerCase();
            if ((filextension!='.jpg')&&(filextension!='.gif')&&(filextension!='.jpeg')&&(filextension!='.png')&&(filextension!='.bmp'))
            {
                alert("对不起，系统仅支持标准格式的照片，请您调整格式后重新上传，谢谢 !");
                imgFile.focus();
            }
            else
            {
                var path;
                if(document.all)//IE
                {
                    imgFile.select();//要解决ie9 和 frame框架下的bug问题，需要找一个元素focus();
                    path = document.selection.createRange().text;
                    document.getElementById("imgPreview").innerHTML="";
                    document.getElementById("imgPreview").style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\"" + path + "\")";//使用滤镜效果
                }
                else//FF
                {
                    path=window.URL.createObjectURL(imgFile.files[0]);// FF 7.0以上
                    document.getElementById("imgPreview").innerHTML = "<img id='img1' width='120px' height='100px' src='"+path+"'/>";
                }
            }
        }

        $(function(){
            $("form").submit(function(){
                var username = $("input[name='username']").val();
                if($.trim(username)==''){
                    alert("用户名称不能为空!");
                    return false;
                }
            });
        })
    </script>

</head>
<body>
	
    <form action="<?php echo U('user/edit');?>" enctype="multipart/form-data" method="post" class="form">
        <table class="table table-bordered">
            <tr>
                <td><label for="username">名称</label></td>
                <td><input type="text" name="username" value="<?php echo ($user['username']); ?>"></td>
                <input type="hidden" name="userid" value="<?php echo ($user['userid']); ?>">
            </tr>
            <tr>
                <td><label for="email">邮箱</label></td>
                <td><input type="text" name="email" value="<?php echo ($user['email']); ?>"></td>
            </tr>
            <tr>
                <td><label for="mobilephone">手机</label></td>
                <td><input type="text" name="mobilephone" value="<?php echo ($user['mobilephone']); ?>"></td>
            </tr>
            <!--<tr>
                <td><label for="isforbidden">是否禁用</label></td>
                <td><input type="radio" name="isforbidden" value="1" <?php if($user['isforbidden']==1){echo "checked";} ?> ></td>
            </tr>-->
            <tr>
                <td><label for="avater">头像</label></td>
                <td>
                    <input type="file" name="avater" onchange='PreviewImage(this)' />
                    <div id="imgPreview"  style='width:120px; height:100px;'></div>
                    <?php if(!empty($user['avater'])): ?><div>
                            <img style="height:40px;" src="/test/upload/avater/<?php echo ($user['avater']); ?>" alt="">
                        </div><?php endif; ?>
                </td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="保存" class="btn"></td>
            </tr>
        </table>
    </form>

</body>
</html>