<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/pblog/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/pblog/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/pblog/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/pblog/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
    </script>

</head>
<body>
	
    <form action="<?php echo U('category/add');?>" method="post" class="form">
        <table class="table table-bordered">
            <tr>
                <td style="width:80px"><label for="catename">父级分类</label></td>
                <td>
                    <select name="catepid" id="">
                        <option value="0">根</option>
                        <?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><option value="<?php echo ($v['cateid']); ?>" <?php if($v['cateid']==$cateid){echo ' selected ';};if($v['level']==2){echo 'disabled';}?>  >
                                    <?php echo str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$v['level']).'|--'.$v['catename'];?>
                                </option><?php endforeach; endif; endif; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="catename">分类名称</label></td>
                <td><input type="text" name="catename"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="添加" class="btn"></td>
            </tr>
        </table>
    </form>

</body>
</html>