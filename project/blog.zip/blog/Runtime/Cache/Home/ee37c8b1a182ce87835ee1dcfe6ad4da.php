<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        function del(articleid,articlename){
            if(confirm("确定要删除博客 ["+articlename+"] 吗?")){
                $.ajax({
                    type: "POST",
                    url: "<?php echo U('article/del');?>",
                    data: "articleid="+articleid,
                    dataType: "json",
                    success: function(json){
                        alert(json.message);
                        window.location.reload();
                    }
                });
            }
        }
    </script>
    <style>
        .wrap div.app{
            border:1px solid #ccc;
        }
        .wrap div.ctrl{
            background:#dee5fa;
            color:#6f9fd5;
            padding:10px;
            font-size:16px;
        }

        .wrap div span{margin-left:10px}
        .wrap div.articles{
            color:#777;
            font-size:16px;
            overflow:hidden;
            padding:10px 0;
        }

        .wrap input{
            margin-top:-4px;
        }
    </style>

</head>
<body>
	
    <br>
    <div class="container">

        <form action="<?php echo U('Article/index');?>" method="post" class="form-inline">
            <label for="cateid">文章分类:</label>
            <select name="cateid" id="">
                <option value="0">根</option>
                <?php if(!empty($cate)): if(is_array($cate)): foreach($cate as $k=>$v): ?><option value="<?php echo ($v['cateid']); ?>" <?php if($v['cateid'] == $where['cateid']): ?>selected<?php endif; ?> ><?php echo str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$v['level']).'|--'.$v['catename'];?></option><?php endforeach; endif; endif; ?>
            </select>
            <label for="articletitle">文章标题:</label>
            <input type="text" name="articletitle" placeholder="文章标题" value="<?php echo ($where['articletitle']); ?>">
            <!--<label for="isforbidden">是否启用:</label>
            <input type="radio" name="isforbidden" value="<?php echo ($where['isforbidden']); ?>">-->

            <button type="submit" class="btn">查询</button>
        </form>

        <table class="table table-bordered">
            <tr>
                <th>文章id</th>
                <th>文章标题</th>
                <th>分类名称</th>
                <th>操作</th>
            </tr>
            <?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><tr>
                        <td><?php echo ($v['articleid']); ?></td>
                        <td><?php echo ($v['articletitle']); ?></td>
                        <td><?php echo ($v['catename']); ?></td>
                        <td>
                            <a href="<?php echo U('article/edit',array('articleid'=>$v['articleid']));?>">[编辑]</a>|
                            <a href="javascript:del(<?php echo ($v['articleid']); ?>,'<?php echo ($v['articletitle']); ?>');">[删除]</a>
                        </td>
                    </tr><?php endforeach; endif; endif; ?>
        </table>
        <?php echo ($page); ?>
    </div>



</body>
</html>