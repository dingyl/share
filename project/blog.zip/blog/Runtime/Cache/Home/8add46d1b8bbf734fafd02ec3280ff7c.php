<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/pblog/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/pblog/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/pblog/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/pblog/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
	<base target="iframe"/>
	<link rel="stylesheet" href="/pblog/public/Admin/Css/index.css" />
	<script type="text/javascript" src="/pblog/public/Admin/Js/index.js"></script>

</head>
<body>
	
	<div id="top">
		<div class="menu">
			<a>欢迎[<?php echo ($adminname); ?>]</a>
		</div>
		<div class="exit">
			<a href="<?php echo U('Index/loginout');?>" target="_self">退出</a>
			<a href="<?php echo U('Index/test');?>">test</a>
			<a href="<?php echo U('Blog/index');?>" target="_self">前台</a>
			<a href="<?php echo U('admin/updatepasswd',array('adminid'=>$adminid));?>">修改密码</a>
		</div>
	</div>
	<div id="left">
		<dl>
			<dt>分类管理</dt>
			<dd><a href="<?php echo U('Category/index');?>">分类列表</a></dd>
			<dd><a href="<?php echo U('Category/add');?>">添加分类</a></dd>
		</dl>
		<dl>
			<dt>权限管理</dt>
			<dd><a href="<?php echo U('ctrl/index');?>">控制器列表</a></dd>
			<dd><a href="<?php echo U('item/index');?>">节点列表</a></dd>
			<dd><a href="<?php echo U('role/index');?>">角色列表</a></dd>
			<dd><a href="<?php echo U('role/edit');?>">添加角色</a></dd>
			<!--<dd><a href="<?php echo U('ctrl/init');?>">控制器初始化</a></dd>-->
		</dl>
		<dl>
			<dt>用户管理</dt>
			<dd><a href="<?php echo U('user/index');?>">用户列表</a></dd>
			<dd><a href="<?php echo U('user/edit');?>">添加用户</a></dd>
		</dl>
		<dl>
			<dt>管理员管理</dt>
			<dd><a href="<?php echo U('admin/index');?>">管理员列表</a></dd>
			<dd><a href="<?php echo U('admin/edit');?>">添加管理员</a></dd>
		</dl>
		<dl>
			<dt>博客管理</dt>
			<dd><a href="<?php echo U('Article/index');?>">文章列表</a></dd>
			<dd><a href="<?php echo U('Article/edit');?>">添加文章</a></dd>
		</dl>
	</div>
	<div id="right">
		<iframe name="iframe"></iframe>
	</div>

</body>
</html>