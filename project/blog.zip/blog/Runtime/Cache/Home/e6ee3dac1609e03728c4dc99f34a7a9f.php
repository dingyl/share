<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <style>
        .wrap div.app{
            border:1px solid #ccc;
        }
        .wrap div.ctrl{
            background:#dee5fa;
            color:#6f9fd5;
            padding:10px;
            font-size:16px;
        }

        .wrap div span{margin-left:10px}
        .wrap div.items{
            color:#777;
            font-size:16px;
            overflow:hidden;
            padding:10px 0;
        }

        .wrap input{
            margin-top:-4px;
        }
    </style>

</head>
<body>
	
    <table class="table table-bordered">
        <tr>
            <th>管理员id</th>
            <th>管理员名称</th>
            <th>邮箱</th>
            <th>角色</th>
            <th>操作</th>
        </tr>
        <?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><tr>
                    <td><?php echo ($v['adminid']); ?></td>
                    <td><?php echo ($v['adminname']); ?></td>
                    <td><?php echo ($v['email']); ?></td>
                    <td><?php echo ($v['rolename']); ?></td>
                    <td>
                        <?php if($v['isforbidden']==1): ?><a href="<?php echo U('admin/manage',array('adminid'=>$v['adminid'],'isforbidden'=>0));?>">[启用]</a>
                            <?php else: ?>
                            <a href="<?php echo U('admin/manage',array('adminid'=>$v['adminid'],'isforbidden'=>1));?>">[禁用]</a><?php endif; ?>
                        |<a href="<?php echo U('admin/edit',array('adminid'=>$v['adminid']));?>">[修改]</a>
                    </td>
                </tr><?php endforeach; endif; endif; ?>
    </table>

</body>
</html>