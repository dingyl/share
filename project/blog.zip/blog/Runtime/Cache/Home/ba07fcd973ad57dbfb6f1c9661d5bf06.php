<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        $(function(){
            $("form").submit(function(){
                var rolename = $("input[name='rolename']").val();
                if($.trim(rolename)==''){
                    alert("角色名称不能为空!");
                    return false;
                }
            });
        })
    </script>

</head>
<body>
	
    <form action="<?php echo U('role/edit');?>" method="post" class="form">
        <table class="table table-bordered">
            <tr>
                <td><label for="rolename">角色名称</label></td>
                <td><input type="text" name="rolename" value="<?php echo ($role['rolename']); ?>"></td>
                <input type="hidden" name="roleid" value="<?php echo ($role['roleid']); ?>">
            </tr>
            <tr>
                <td><label for="mark">角色备注</label></td>
                <td><input type="text" name="mark" value="<?php echo ($role['mark']); ?>"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="保存" class="btn"></td>
            </tr>
        </table>
    </form>

</body>
</html>