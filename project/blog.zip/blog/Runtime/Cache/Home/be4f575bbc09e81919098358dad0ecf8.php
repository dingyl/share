<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        $(function(){
            $("form").submit(function(){
                var adminname = $("input[name='adminname']").val();
                if($.trim(adminname)==''){
                    alert("管理员名称不能为空!");
                    return false;
                }
            });
        })
    </script>

</head>
<body>
	
    <form action="<?php echo U('admin/edit');?>" method="post" class="form">
        <table class="table table-bordered">
            <tr>
                <td><label for="adminname">名称</label></td>
                <td><input type="text" name="adminname" value="<?php echo ($admin['adminname']); ?>"></td>
                <input type="hidden" name="adminid" value="<?php echo ($admin['adminid']); ?>">
            </tr>
            <tr>
                <td><label for="email">邮箱</label></td>
                <td><input type="text" name="email" value="<?php echo ($admin['email']); ?>"></td>
            </tr>
            <tr>
                <td><label for="roleid">角色</label></td>
                <td>
                    <select name="roleid" id="">
                        <?php if(!empty($role)): if(is_array($role)): foreach($role as $k=>$v): ?><option value="<?php echo ($v['roleid']); ?>"  <?php if($v['roleid'] == $admin['roleid']): ?>selected<?php endif; ?> ><?php echo ($v['rolename']); ?></option><?php endforeach; endif; endif; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="保存" class="btn"></td>
            </tr>
        </table>
    </form>

</body>
</html>