<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        $(function(){
            $("form").submit(function(){
                var oldpasswd = $("input[name='oldpasswd']").val();
                var passwd = $("input[name='passwd']").val();
                var repasswd = $("input[name='repasswd']").val();
                if(oldpasswd==''){
                    alert("请输入原密码");
                    return false;
                }else{
                    if(passwd!=repasswd){
                        alert("新密码不一致");
                        return false;
                    }
                }
            });
        })
    </script>

</head>
<body>
	
    <form action="<?php echo U('admin/updatepasswd');?>" method="post" class="form">
        <table class="table table-bordered">
            <tr>
                <td><label for="oldpasswd">旧密码</label></td>
                <td><input type="password" name="oldpasswd" ></td>
                <input type="hidden" name="adminid" value="<?php echo ($adminid); ?>">
            </tr>
            <tr>
                <td><label for="passwd">新密码</label></td>
                <td><input type="password" name="passwd" ></td>
            </tr>
            <tr>
                <td><label for="repasswd">重复密码</label></td>
                <td><input type="password" name="repasswd" ></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="确定" class="btn"></td>
            </tr>
        </table>
    </form>

</body>
</html>