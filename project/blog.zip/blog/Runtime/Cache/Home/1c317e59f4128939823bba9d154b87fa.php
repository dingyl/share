<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/pblog/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/pblog/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/pblog/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/pblog/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        $(function(){
            $(".update").click(function(){
                var parent = $(this).parent().parent();
                var itemid = parent.find("input[name='itemid']").val();
                var mark = parent.find("input[name='mark']").val();
                $.ajax({
                    type: "POST",
                    url: "<?php echo U('item/edit');?>",
                    data: "itemid="+itemid+"&mark="+mark,
                    dataType: "json",
                    success: function(json){
                        alert(json.message);
                        window.location.reload();
                    }
                });
            });
        });
    </script>
    <style>
        .wrap div.app{
            border:1px solid #ccc;
        }
        .wrap div.ctrl{
            background:#dee5fa;
            color:#6f9fd5;
            padding:10px;
            font-size:16px;
        }

        .wrap div span{margin-left:10px}
        .wrap div.items{
            color:#777;
            font-size:16px;
            overflow:hidden;
            padding:10px 0;
        }

        .wrap input{
            margin-top:-4px;
        }
    </style>

</head>
<body>
	
    <table class="table table-bordered">
        <tr>
            <th>节点编号</th>
            <th>节点名称</th>
            <th>备注</th>
            <th>控制器名称</th>
            <th>操作</th>
        </tr>
        <?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><tr>
                    <td>
                        <?php echo ($v['itemid']); ?>
                        <input type="hidden" name="itemid" value="<?php echo ($v['itemid']); ?>">
                    </td>
                    <td><?php echo ($v['itemname']); ?></td>
                    <td><input type="text" name="mark" value="<?php echo ($v['mark']); ?>"></td>
                    <td><?php echo ($v['ctrlname']); ?></td>
                    <td>
                        <a class="update" href="javascript:;">[更新]</a>
                    </td>
                </tr><?php endforeach; endif; endif; ?>
    </table>

</body>
</html>