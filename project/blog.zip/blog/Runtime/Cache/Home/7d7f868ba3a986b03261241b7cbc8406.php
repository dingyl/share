<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/pblog/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/pblog/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/pblog/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/pblog/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
    <script>
        function del(cateid,catename){
            if(confirm("确定要删除分类 ["+catename+"] 吗?\r\n删除后，与其相关的博客就没有分类了!")){
                $.ajax({
                    type: "POST",
                    url: "<?php echo U('category/del');?>",
                    data: "cateid="+cateid,
                    dataType: "json",
                    success: function(json){
                        if(json.status){
                            alert("分类删除成功");
                            window.location.reload();
                        }else{
                            alert(json.message);
                        }
                    }
                });
            }
        }
    </script>

</head>
<body>
	
    <table class="table table-bordered table-hover">
        <tr>
            <th>分类编号</th>
            <th>分类名</th>
            <th>操作</th>
        </tr>
        <?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><tr>
                    <td><?php echo ($v['cateid']); ?></td>
                    <td><?php echo str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$v['level']).'|--'.$v['catename'];?></td>
                    <td>
                        <a href="<?php echo U('category/edit',array('cateid'=>$v['cateid']));?>">[编辑]</a>|
                        <?php if(isset($v['isfinal'])): ?><a href="javascript:;" onclick="del(<?php echo ($v['cateid']); ?>,'<?php echo ($v['catename']); ?>');">[删除]</a>|<?php endif; ?>
                        <?php if($v['level'] != 2): ?><a href="<?php echo U('category/add',array('cateid'=>$v['cateid']));?>">[添加子分类]</a><?php endif; ?>

                    </td>
                </tr><?php endforeach; endif; endif; ?>
    </table>

</body>
</html>