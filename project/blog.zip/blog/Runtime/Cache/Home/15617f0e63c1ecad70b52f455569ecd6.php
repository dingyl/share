<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript" src="/test/public/Admin/Js/jquery-1.7.2.min.js"></script>
	<!--<link rel="stylesheet" href="/test/public/Admin/Css/public.css" />-->
	<script type="text/javascript" src="/test/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="/test/bootstrap/css/bootstrap.min.css" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	
	<script>
        /*function del(itemid,itemname){
            if(confirm("确定要删除节点 ["+itemname+"] 吗?")){
                $.ajax({
                    type: "POST",
                    url: "<?php echo U('item/del');?>",
                    data: "itemid="+itemid,
                    dataType: "json",
                    success: function(json){
                        if(json.status){
                            alert("节点删除成功");
                            window.location.reload();
                        }else{
                            alert(json.message);
                        }
                    }
                });
            }
        }*/
	</script>
	<style>
		.wrap div.app{
			border:1px solid #ccc;
		}
		.wrap div.ctrl{
			background:#dee5fa;
			color:#6f9fd5;
			padding:10px;
			font-size:16px;
		}

		.wrap div span{margin-left:10px}
		.wrap div.items{
			color:#777;
			font-size:16px;
			overflow:hidden;
			padding:10px 0;
		}

		.wrap input{
			margin-top:-4px;
		}
	</style>

</head>
<body>
	
	<table class="table table-bordered">
		<tr>
			<th>用户id</th>
			<th>用户名称</th>
			<th>邮箱</th>
			<th>电话</th>
			<th>头像</th>
			<th>操作</th>
		</tr>
		<?php if(count($list) > 0): if(is_array($list)): foreach($list as $k=>$v): ?><tr>
					<td><?php echo ($v['userid']); ?></td>
					<td><?php echo ($v['username']); ?></td>
					<td><?php echo ($v['email']); ?></td>
					<td><?php echo ($v['mobilephone']); ?></td>
					<td>
						<img style="height:40px;" src="/test/upload/avater/<?php echo ($v['avater']); ?>" alt="">
					</td>
					<td>
						<?php if($v['isforbidden']==1): ?><a href="<?php echo U('user/manage',array('userid'=>$v['userid'],'isforbidden'=>0));?>">[启用]</a>
							<?php else: ?>
							<a href="<?php echo U('user/manage',array('userid'=>$v['userid'],'isforbidden'=>1));?>">[禁用]</a><?php endif; ?>
						|<a href="<?php echo U('user/edit',array('userid'=>$v['userid']));?>">[修改]</a>
					</td>
				</tr><?php endforeach; endif; endif; ?>
	</table>

</body>
</html>