<?php 
function p($arr){
	echo "<pre>";
	print_r($arr);
	echo "</pre>";
}

function getChild($pid,$tree,$level=0){
	$temp = array();
	foreach($tree as $k=>$v){
		if($v['catepid']==$pid){
            $v['level']=$level;
            unset($tree[$k]);
			$v['child']=getChild($v['cateid'],$tree,$level+1);
			if(count($v['child'])==0){
                unset($v['child']);
			}
			$temp[]=$v;
		}
	}
	return $temp;
}

function getChildList($pid,$tree,&$arr,$level=0){
    foreach($tree as $k=>$v){
        if($v['catepid']==$pid){
            unset($tree[$k]);
            $v['level']=$level;
            $count = count(getChild($v['cateid'],$tree));
            if($count==0){
            	$v['isfinal']=true;
			}
            array_push($arr,$v);
            getChildList($v['cateid'],$tree,$arr,$level+1);
        }
    }
}

function className($name,$path=''){
    $layer  =   C('DEFAULT_C_LAYER');
    if(!C('APP_USE_NAMESPACE')){
        $class  =   parse_name($name, 1).$layer;
        import(MODULE_NAME.'/'.$layer.'/'.$class);
    }else{
        $class  =   MODULE_NAME.'\\'.($path?$path.'\\':'').$layer;
        $array  =   explode('/',$name);
        foreach($array as $name){
            $class  .=   '\\'.parse_name($name, 1);
        }
        $class .=   $layer;
    }
    return $class;
}

function success($url,$msg){
    header('Content-Type:text/html;charset=utf-8');
    echo "<script type='text/javascript'>alert('{$msg}');location.href='".U($url)."'</script>";
}
function error($msg){
    header('Content-Type:text/html;charset=utf-8');
    echo "<script type='text/javascript'>alert('{$msg}');window.history.back();</script>";
}
?>
