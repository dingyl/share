<?php
namespace Home\Widget;
use Think\Controller;
class CommentWidget  extends Controller {
    public function commentlist(){

    }
}
?>