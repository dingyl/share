<?php
namespace Home\Controller;
use Think\Controller;
class BackController extends Controller {

    public function _initialize ()
    {
        //进行权限验证
        if(!session("islogin")){//没有登陆
            $this->error("你还没有登陆!请先登录",U('index/login'),1);die;
        }else{//登陆成功
            $superuser = C('SUPER_USER');//超级用户不需要验证权限
            if($superuser!=session('adminname')){
                $ctrlname =  strtolower(CONTROLLER_NAME);
                $actionname =  strtolower(ACTION_NAME);
                //获取用户的角色id
                $roleid = M('admin')->where(array('adminid'=>session('adminid')))->getField('roleid');
                $roit = M('role_item');
                //获取角色的所有权限节点
                $itemnames = $roit->join("left join item on role_item.itemid=item.itemid")->where(array('roleid'=>$roleid))->getField('itemname',true);
                $tname = $ctrlname."_".$actionname;
                if(!in_array($tname,$itemnames)){//没有权限
                    $this->display("common/deny");die;
                }
            }
        }
    }

}
?>