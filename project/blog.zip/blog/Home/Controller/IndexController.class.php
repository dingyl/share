<?php
namespace Home\Controller;
use Think\Cache\Driver\Memcache;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        if(session("islogin")){
            $data = array();
            $data['adminname']=session("adminname");
            $data['adminid']=session("adminid");
            $data['islogin']=session("islogin");
            $this->assign($data);
        }else{
            $this->redirect("index/login");die;
        }
        $this->show();
    }
    public function login(){
        if(session("islogin")){
            $this->redirect("index/index");die;
        }

        if(IS_POST){
            $aname = I("adminname");
            $apasswd = md5(I("passwd"));
            $code = I("code");
            $data['adminname'] = $aname;
            $verify = new \Think\Verify();
            if($verify->check($code,1)){
                $ad = M("admin");
                $temp = $ad->where(array('adminname'=>$aname,'passwd'=>$apasswd,'isforbidden'=>0))->select();
                $count = count($temp);
                if($count){
                    if($temp[0]['isforbidden']==1){
                        $this->error("用户已被禁用","login");die;
                    }
                    session('adminname',$aname);
                    session('adminid',$temp[0]['adminid']);
                    session('islogin',true);
                    $this->success("登陆成功","index");die;
                }else{
                    $this->error("用户名或密码错误","login");die;
                }
            }else{
                $this->error("验证码错误!","login");die;
            }
        }
        $this->show();
    }

    public function loginout(){
        session('adminname',null);
        session('adminid',null);
        session('islogin',null);
        $this->redirect("Index/login");
    }

    public function verify(){
        $Verify = new \Think\Verify();
        $Verify->fontSize = 40;
        $Verify->length   = 4;
        $Verify->useNoise = false;
        $Verify->entry(1);
    }

    public function test(){
        /*$name = I('name');
        var_dump($name);
        var_dump(addslashes($name));*/
        p($_SESSION);
    }
}