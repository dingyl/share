<?php
namespace Home\Controller;
use Think\Controller;
class CtrlController extends BackController {

    public function index(){
        $data = array();
        $ctrl = M('ctrl');
        $data['list'] = $ctrl->select();
        $this->assign($data);
        $this->show();
    }

    public function init(){
        $ctrl = M('ctrl');
        $item = M('item');
        $ctrl->execute("truncate ctrl");
        $ctrl->execute("truncate item");
        $ctrl->execute("truncate role_item");
        $dir = dirname(__FILE__);
        $dh = opendir($dir);

        //配置需要权限验证的控制器
        $needctrl = array('admin','article','category','ctrl','item','role','user');
        $status = true;
        while($file = readdir($dh)){
            $filepath = $dir.DIRECTORY_SEPARATOR.$file;
            if(is_file($filepath)){
                $class = substr($file,0,strpos($file,'Controller'));
                $class = strtolower($class);
                if(in_array($class,$needctrl)){
                    $cname = className($class);
                    $methods = get_class_methods($cname);
                    //配置去除的节点方法
                    $default = array('test','_initialize','__construct','display','show','fetch','buildHtml','theme','assign','__set','get','__get','__isset','__call','error','success','ajaxReturn','redirect','__destruct');
                    $temp = array_diff($methods,$default);
                    $data = array('ctrlname'=>$class);
                    if($ctrlid = $ctrl->add($data)){//插入成功
                        $datatemp = array();
                        foreach ($temp as $v){
                            $datatemp[]=array('itemname'=>$class."_".strtolower($v),'ctrlid'=>$ctrlid);
                        }
                        $item->addAll($datatemp);
                    }else{
                        $status = false;
                    }
                }
            }
        }
        if($status){
            $this->success("初始化成功","index");
        }else{
            $this->error("初始化失败","index");
        }
    }

    public function edit($ctrlid=0){
        $data = array();
        $ctrl = M('ctrl');
        $data['ctrl']=$ctrl->where(array('ctrlid'=>$ctrlid))->select()[0];
        if(IS_POST){
            if(!empty(I('ctrlid'))){
                $ctrl->create();
                if($ctrl->save()===false){
                    echo json_encode(array('message'=>"更新控制器失败"));die;
                }else{
                    echo json_encode(array('message'=>"更新控制器成功"));die;
                }
            }
        }
        $this->assign($data);
        $this->show();
    }
}
?>