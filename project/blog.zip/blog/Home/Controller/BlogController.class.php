<?php
namespace Home\Controller;
use Think\Controller;
class BlogController extends FrontController {

    public function index(){
        $article = M('article');
        $data = array();

        $where=array();
        if(I('keyword')){
            $where['articletitle']=array('like',"%".I('keyword')."%");
        }

        $count = $article->where($where)->count();
        $Page       = new \Think\Page($count,25);
        $data['articlelist'] = $article->where($where)->order('clickcount desc,createtime desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $show       = $Page->show();
        $data['page'] = $show;
        $this->assign($data);
        $this->show();
    }

    public function catebloglist($cateid){//二级分类id
        $cate = M('category');
        $subcatelist = $cate->where(array('catepid'=>$cateid))->select();
        $data = array();
        $article = M('article');
        foreach($subcatelist as $k=>$v){
            $articlelist = $article->where(array('cateid'=>$v['cateid']))->limit(5)->select();
            $subcatelist[$k]['articlelist']=$articlelist;
        }

        $data['subcatelist'] = $subcatelist;

        $this->assign($data);
        $this->show();
    }

    public function bloglist($cateid){//三级分类id
        $article = M('article');
        $data = array();
        $articlelist = $article->where(array('cateid'=>$cateid))->select();
        $data['articlelist'] = $articlelist;

        $temp = array();
        $catepath = $this->getcatepath($cateid,$temp);
        $data['firstcate'] = array_pop($temp);
        $data['secondcate'] = array_pop($temp);
        $data['thirdcate'] = array_pop($temp);

        $this->assign($data);
        $this->show();
    }

    public function blogshow($articleid){
        $data = array();
        $sql="update article set clickcount=clickcount+1 where articleid=$articleid";
        M()->execute($sql);
        $art = M('article');
        $article=$art->where(array('articleid'=>$articleid))->select()[0];
        $data['article'] = $article;

        //获取文章分类路径
        $temp = array();
        $catepath = $this->getcatepath($articleid,$temp);
        $data['firstcate'] = array_pop($temp);
        $data['secondcate'] = array_pop($temp);
        $data['thirdcate'] = array_pop($temp);


        //获取文章的所有评论
        $data['comlist'] = $this->getCommentList($articleid);

        $this->assign($data);
        $this->show();
    }

    public function getcatepath($cateid,&$arr){
        $cate = M('category');
        $temp = $cate->where(array('cateid'=>$cateid))->select()[0];
        array_push($arr,$temp);
        if(!empty($temp['catepid'])){
            $this->getcatepath($temp['catepid'],$arr);
        }
    }

    public function getCommentList($articleid){
        $comment = M('comment');
        $temptree = $comment->join("left join user on user.userid=comment.uid")->where(array('articleid'=>$articleid))->select();
        $arr = array();
        $this->getSonList(0,$temptree,$arr);
        return $arr;
    }

    public function getSonList($pid,$tree,&$arr,$level=0){
        foreach($tree as $k=>$v){
            if($v['replyid']==$pid){
                $v['level']=$level;
                array_push($arr,$v);
                $this->getSonList($v['commentid'],$tree,$arr,$level+1);
            }
        }
    }

    public function login(){
        if(session('islogined')){
            $this->redirect("index");die;
        }

        if(IS_POST){
            $username = I("username");
            $passwd = md5(I("passwd"));
            $code = I("verifycode");
            $data['username'] = $username;
            $verify = new \Think\Verify();
            if($verify->check($code,2)){
                $user = M("user");
                $temp = $user->where(array('username'=>$username,'passwd'=>$passwd,'isforbidden'=>0))->select();
                $count = count($temp);
                if($count){
                    session('username',$username);
                    session('userid',$temp[0]['userid']);
                    session('avater',$temp[0]['avater']);
                    session('islogined',true);
                    $this->success("登陆成功","index");die;
                }else{
                    $this->error("用户名或密码错误","login");die;
                }
            }else{
                $this->error("验证码错误!","login");die;
            }
        }
        $this->show();
    }

    public function register(){
        if(IS_POST){
            $_POST['passwd'] = md5(I("passwd"));
            $user = M('user');
            $user->create();
            $id = $user->add();
            if($id){
                session('username',I('username'));
                session('userid',$id);
                session('islogined',true);
                $this->success("注册成功","index");die;
            }else{
                $this->error("注册失败","register");die;
            }
        }
        $this->show();
    }

    public function updatepwd($userid){
        if(session('userid')==$userid){
            if(IS_POST){
                $user = M('user');
                $count = $user->where(array('userid'=>$userid,'passwd'=>md5(I('oldpasswd')),'isforbidden'=>0))->count();
                if($count){
                    $_POST['passwd']=md5($_POST['passwd']);
                    $user->create();
                    if($user->save()){
                        $this->success("修改密码成功","index");die;
                    }else{
                        $this->error("修改密码失败");die;
                    }
                }else{
                    $this->error("原密码不正确");die;
                }

            }
        }else{
            $this->error("只能修改自己的密码");die;
        }
        $this->show();
    }

    public function editinfo($userid){
        $data = array();
        $user = M('user');
        if(session('userid')==$userid) {
            if (IS_POST) {//更新操作
                $error = $_FILES['avater']['error'];
                if($error==0) {
                    $upload = new \Think\Upload();// 实例化上传类
                    $upload->maxSize = 3145728;// 设置附件上传大小
                    $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
                    $upload->rootPath = './upload/avater/';
                    $info = $upload->upload();
                    if (!$info) {
                        $this->error($upload->getError());die;
                    } else {
                        $_POST['avater'] = $info['avater']['savepath'] . $info['avater']['savename'];
                    }
                }
                $user->create();
                if($user->save()){
                    session('username',I('username'));
                    session('avater',I('avater'));
                    $this->success('更新信息成功！','index');die;
                }else{
                    $this->error('更新信息失败！','index');die;
                }
            }
        }else{
            $this->error('只能更新自己的信息！');
        }
        $data['user'] = $user->where(array('userid'=>$userid))->select()[0];
        $this->assign($data);
        $this->show();
    }

    public function loginout(){
        session('username',null);
        session('userid',null);
        session('islogined',null);
        $this->success("已退出登陆","index");die;
    }


    /**
     * 发布评论
     * @param $articleid 评论博客id
     * @param int $replyid 回复评论id
     */
    public function comment($articleid,$replyid=0){
        $comment = M('comment');
        $_POST['commentext'] = addslashes($_POST['commentext']);
        $_POST['createtime'] = time();
        $comment->create();
        if($comment->add()){
            echo json_encode(array('message'=>"评论成功"));
        }else{
            echo json_encode(array('message'=>"评论失败"));
        }
    }

    public function verify(){
        $Verify = new \Think\Verify();
        $Verify->fontSize = 40;
        $Verify->length   = 4;
        $Verify->useNoise = false;
        $Verify->entry(2);
    }

}
?>