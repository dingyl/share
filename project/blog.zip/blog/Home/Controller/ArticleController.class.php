<?php
namespace Home\Controller;
use Think\Page;
use Think\Controller;
class ArticleController extends BackController {

    public function index(){
        $data = array();
        $article = M('article');
        if(I('cateid')){
            $where['category.cateid']=I('cateid');
        }
        if(!empty(I('articletitle'))){
            $where['articletitle']=array('like',"%".I('articletitle')."%");
        }
        $where['_logic'] = 'OR';
        $count = $article->join("left join category on article.cateid=category.cateid")->where($where)->count();
        $Page       = new \Think\Page($count,10);
        $data['list'] = $article->join("left join category on article.cateid=category.cateid")->where($where)->order('createtime desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $show       = $Page->show();
        $data['page'] = $show;
        $tree = M('category')->select();
        $list = array();
        getChildList(0,$tree,$list);
        $data['cate'] = $list;
        $where['articletitle']=I('articletitle');
        $where['cateid']=I('cateid');
        $data['where'] = $where;
        $this->assign($data);
        $this->show();
    }

    public function edit($articleid=0){
        $data = array();
        $article = M('article');
        $data['article']=$article->where(array('articleid'=>$articleid))->select()[0];
        $tree = M('category')->select();
        $list = array();
        getChildList(0,$tree,$list);
        $data['cate'] = $list;
        if(IS_POST){
            if(I('articleid')==0){
                unset($_POST['articleid']);
                $_POST['createtime']=time();
                $article->create();
                if($article->add()){
                    $this->success("更新博客成功","index");die;
                }else{
                    $this->redirect('article/edit', array('articleid' => I('articleid')), 1, '更新博客失败');die;
                }
            }else{
                $article->create();
                if($article->save()){
                    $this->success("更新博客成功","index");die;
                }else{
                    $this->redirect('article/edit', array('articleid' => I('articleid')), 1, '更新博客失败');die;
                }
            }
        }
        $this->assign($data);
        $this->show();
    }

    public function del($articleid){
        $data = array();
        $article = M('article');
        $data['status']=false;
        $status = $article->where(array('articleid'=>$articleid))->delete();
        if($status){
            $data['status']=true;
            $data['message']="博客删除成功";
        }else{
            $data['message']="博客删除失败";
        }
        echo json_encode($data);
    }

    //editor中的图片啊上传
    public function imgupload(){
        if($_FILES['imgFile']['error']==0){
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');
            $upload->rootPath  =     './upload/editor/img/';
            $info   =   $upload->upload();
            if(!$info){
                echo json_encode(array('error'=>1,'message'=>$upload->getError()));
            }else{
                $file_url = $info['imgFile']['savepath'].$info['imgFile']['savename'];
                echo json_encode(array('error' => 0, 'url' =>  __ROOT__."/upload/editor/img/".$file_url));
            }
        }
    }
}
?>