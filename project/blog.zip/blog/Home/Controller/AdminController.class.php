<?php
namespace Home\Controller;
use Think\Controller;
class AdminController extends BackController {
    //列表页
    public function index(){
        $data = array();
        $admin = M('admin');
        $data['list'] = $admin->field(array('adminid','adminname','email','rolename','isforbidden'))->join("left join role on admin.roleid=role.roleid")->select();

        //p($data);
        $this->assign($data);
        $this->show();
    }
    //编辑用户
    public function edit($adminid=0){
        $data = array();
        $admin = M('admin');
        if(IS_POST){//更新操作
            $admin->create();
            if(I('adminid')==0) {//添加
                if($admin->add()){
                    $this->success('添加成功！','index');die;
                }
            }else{
                if($admin->save()){
                    session('adminname',I('adminname'));
                    $this->success('更新成功！','index');die;
                }
            }
        }
        $data['admin'] = $admin->where(array('adminid'=>$adminid))->select()[0];
        $data['role'] = M('role')->select();
        $this->assign($data);
        $this->show();
    }

    //只能修改自己的密码
    public function updatepasswd($adminid){
        if(session('adminid')==$adminid){
            if(IS_POST){
                $passwd=md5($_POST['oldpasswd']);
                $_POST['passwd']=md5($_POST['passwd']);
                $admin = M('admin');
                $temp = $admin->where(array('adminid'=>$adminid,'passwd'=>$passwd))->select();
                if(count($temp)){
                    $admin->create();
                    if($admin->save()){
                        $this->success("更新密码成功","index");die;
                    }else{
                        $this->error("更新密码失败","index");die;
                    }
                }else{
                    $this->error("原密码不正确","index");die;
                }
            }
            $data = array();
            $data['adminid']=$adminid;
            $this->assign($data);
            $this->show();
        }else{
            $this->error("只能修改自己的密码","index");die;
        }
    }


    //启，禁用户
    public function manage(){
        $admin = M('admin');
        $admin->create($_GET);
//        p($_GET);
//        p($admin);die;
        if($admin->save()){
            $this->redirect("admin/index");die;
        }else{
            $this->redirect("admin/index");die;
        }
    }
}
?>