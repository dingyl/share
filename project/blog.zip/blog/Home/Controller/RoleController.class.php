<?php
namespace Home\Controller;
use Think\Controller;
class RoleController extends BackController {

    public function index(){
        $data = array();
        $role = M('role');
        $data['list'] = $role->select();
        $this->assign($data);
        $this->show();
    }

    public function edit($roleid=0){
        $data = array();
        $role = M('role');
        $data['role']=$role->where(array('roleid'=>$roleid))->select()[0];
        if(IS_POST){
            if(I('roleid')==0){
                unset($_POST['roleid']);
                $role->create();
                if($role->add()){
                    $this->success("更新角色成功","index");die;
                }else{
                    $this->redirect('role/edit', array('roleid' => I('roleid')), 1, '更新角色失败');die;
                }
            }else{
                $role->create();
                if($role->save()){
                    $this->success("更新角色成功","index");die;
                }else{
                    $this->redirect('role/edit', array('roleid' => I('roleid')), 1, '更新角色失败');die;
                }
            }
        }
        $this->assign($data);
        $this->show();
    }

    public function grant($roleid){
        $data = array();
        $item = M('item');
        $message = array();
        $message['status'] = true;
        $message['message'] = "更新角色权限成功";
        $roleitem = M('role_item');
        if(IS_POST){
            $roleitem->where(array('roleid'=>$roleid))->delete();
            $itemids = I("itemids");
            if(!empty($itemids)){
                $ids = explode(',',$itemids);
                $temp = array();
                foreach($ids as $v){
                    $temp[]=array('roleid'=>$roleid,'itemid'=>$v);
                }
                if(!$roleitem->addAll($temp)){
                    $message['status'] = false;
                    $message['message'] = "更新角色权限失败";
                }
            }
            echo json_encode($message);die;
        }
        $idarr = $roleitem->where(array('roleid'=>$roleid))->getField('itemid',true);
        $data['itemids'] = $idarr;
        $list = $item->field(array('itemid','itemname','item.mark'=>'mark','ctrl.mark'=>'ctrlmark','item.ctrlid'=>'ctrlid','ctrlname','ctrl.mark'=>'ctrlmark'))->join("left join ctrl on item.ctrlid=ctrl.ctrlid")->order("ctrl.ctrlid")->select();
        $temp = array();
        foreach ($list as $k=>$v){
            $temp[$v['ctrlmark']][] = $v;
        }
        $data['roleid']=$roleid;
        $data['rolename']=M('role')->where(array('roleid'=>$roleid))->getField('rolename');
        $data['list'] = $temp;
        $this->assign($data);
        $this->show();
    }

    public function del($roleid){
        $data = array();
        $role = M('role');
        $data['status']=false;
        $status = $role->where(array('roleid'=>$roleid))->delete();
        if($status){
            $data['status']=true;
            $data['message']="角色删除成功";
        }else{
            $data['message']="角色删除失败";
        }

        echo json_encode($data);
    }
}
?>