<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends BackController {
	//列表页
    public function index(){
        $data = array();
        $user = M('user');
        $data['list'] = $user->select();
        $this->assign($data);
        $this->show();
    }
	//编辑用户
    public function edit($userid=0){
        $data = array();
        $user = M('user');
        if(IS_POST){//更新操作
            $error = $_FILES['avater']['error'];
            if($error==0) {
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize = 3145728;// 设置附件上传大小
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
                $upload->rootPath = './upload/avater/';
                $info = $upload->upload();
                if (!$info) {
                    $this->error($upload->getError());die;
                } else {
                    $_POST['avater'] = $info['avater']['savepath'] . $info['avater']['savename'];
                }
            }
            $user->create();
            if(I('userid')==0) {//添加
                if($user->add()){
                    $this->success('添加成功！','index');die;
                }
            }else{
                if($user->save()){
                    $this->success('更新成功！','index');die;
                }
            }

        }
        $data['user'] = $user->where(array('userid'=>$userid))->select()[0];
        $this->assign($data);
        $this->show();
    }

    //启，禁用户
    public function manage(){
        $user = M('user');
        $user->create($_GET);
        if($user->save()){
            $this->redirect("user/index","更新完成");die;
        }else{
            $this->redirect("user/index","更新失败");die;
        }
    }
}
?>