<?php
namespace Home\Controller;
use Think\Controller;
class ItemController extends BackController {

    public function index(){
        $data = array();
        $item = M('item');
        $list = $item->field(array('itemid','itemname','ctrlname','item.ctrlid'=>'ctrlid','item.mark'=>'mark'))->join("left join ctrl on item.ctrlid=ctrl.ctrlid")->order("ctrl.ctrlid")->select();
        $data['list'] = $list;
        $this->assign($data);
        $this->show();
    }

    public function edit($itemid=0){
        $data = array();
        $item = M('item');
        $data['item']=$item->where(array('itemid'=>$itemid))->select()[0];
        $data['ctrl'] = M('ctrl')->select();
        if(IS_POST){
            if(!empty(I('itemid'))){
                $item->create();
                if($item->save()===false){
                    echo json_encode(array('message'=>"更新节点失败"));die;
                }else{
                    echo json_encode(array('message'=>"更新节点成功"));die;
                }
            }
        }
        $this->assign($data);
        $this->show();
    }
}
?>