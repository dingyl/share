<?php
namespace Home\Controller;
use Think\Controller;
class FrontController extends Controller {

    public function _initialize(){
        $data = array();
        $actionname = ACTION_NAME;
        $namelist = array('login','register','verify','loginout');
        if(!in_array($actionname,$namelist)){
            if(empty(S('catelist'))){
                $cate = M('category');
                $tree = $cate->select();
                S('catelist',getChild(0,$tree),3600*24);
            }
            $data['catelist'] = S('catelist');
            $num = 10;
            empty(S('hotarticle'))?S('hotarticle',M('article')->order('clickcount desc')->limit($num)->select(),60):S('hotarticle');
            $data['hotarticle'] = S('hotarticle');
            empty(S('newarticle'))?S('newarticle',M('article')->order('createtime desc')->limit($num)->select(),60):S('newarticle');
            $data['newarticle'] = S('newarticle');
        }
        $this->assign($data);
    }
}
?>