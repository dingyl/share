<?php
namespace Home\Controller;
use Think\Controller;
class CategoryController extends BackController {

    public function index(){
        $data = array();
        $cate = M('category');
        $tree = $cate->select();
        $list = array();
        getChildList(0,$tree,$list);
        $data['list'] = $list;
        $this->assign($data);
        $this->show();
    }

    public function add($cateid=0){
        $data = array();
        $cate = M('category');
        $data['cateid']=$cateid;
        if(IS_POST){
            $cate->create();
            if($cate->add()){
                $this->success("添加分类成功","index",0);die;
            }else{
                $this->redirect('Category/add', array('cateid' => I('catepid')), 1, '添加分类失败');die;
            }
        }
        $tree = $cate->select();
        $list = array();
        getChildList(0,$tree,$list);
        $data['list']=$list;
        $this->assign($data);
        $this->show();
    }

    public function edit($cateid){
        $data = array();
        $cate = M('category');
        if(IS_POST){
            $cate->create();
            $status = $cate->save();
            if($status){
                $this->redirect("Category/edit");die;
            }else{
                $this->redirect('Category/edit', array('cateid' => I('cateid')), 1, '修改分类失败');die;
            }

        }
        $tree = $cate->select();
        $list = array();
        getChildList(0,$tree,$list);
        $data['list']=$list;
        $data['cate']=array();
        foreach($list as $k=>$v){
            if($v['cateid']==$cateid){
                $data['cate'] = $v;
                break;
            }
        }
        $this->assign($data);
        $this->show();
    }

    public function del($cateid){
        $data = array();
        $cate = M('category');
        $data['status']=false;
        $count = $cate->where(array('catepid'=>$cateid))->count();
        if($count>0){
            $data['message']="请先将子分类删除";
        }else{
            $status = $cate->where(array('cateid'=>$cateid))->delete();
            if($status){
                $data['status']=true;
                $data['message']="删除分类成功";
            }else{
                $data['message']="分类删除失败";
            }
        }
        echo json_encode($data);
    }
}
?>