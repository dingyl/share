<?php
namespace Home\Model;
use Think\Model;
class UserModel extends Model {
    protected $_validate = array(
     	array('username','require','用户名已经存在',0,'unique',1), //默认情况下用正则进行验证
     	array('passwd','require','密码不能为空'),
     	array('repassword','passwd','确认密码不正确',0,'confirm')
    );
    protected $_auto = array (
	    array('passwd','md5',3,'function')
	);
}
?>