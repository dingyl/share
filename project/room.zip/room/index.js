window.onload = function()
{
	var oDiv = $('content_left');
	var oWrap = $('wrap');
	
	var now=0;
	var aUl = oWrap.getElementsByTagName('ul')[0];
	var aLi = oDiv.getElementsByTagName('li');
	var oLi = oWrap.getElementsByTagName('li');
	for(var i=0;i<oLi.length;i++)
	{
		oLi[i].index=i;
	}
	
	for(var i=0;i<aLi.length;i++)
	{
		aLi[i].index=i;
		aLi[i].onclick=function()
		{
			startMove(aUl, {marginLeft:-this.index * oLi[0].offsetWidth});
			now=this.index;
		}
	}
	
	var opre = $('prev');
	var onex = $('next');
	
	onex.onclick=function()
	{
		if(now<aLi.length-1)
		{
			startMove(aUl, {marginLeft:-(++now) * oLi[0].offsetWidth});
		}
	}
	opre.onclick=function()
	{
		if(now>0)
		{
			startMove(aUl, {marginLeft:-(--now) * oLi[0].offsetWidth});
		}
	}
}