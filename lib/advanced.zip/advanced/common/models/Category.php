<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "category".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property integer $pid
 * @property integer $level
 * @property string $son_ids
 * @property string $cate_path
 * @property integer $created_at
 * @property integer $updated_at
 */
class Category extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'category';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['pid', 'level', 'created_at', 'updated_at'], 'integer'],
            [['name', 'description'], 'string', 'max' => 32],
            [['son_ids'], 'string', 'max' => 255],
            [['cate_path'], 'string', 'max' => 48],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => '分类名称',
            'description' => '分类描述',
            'pid' => '父分类',
            'level' => '分类级别',
            'son_ids' => '子分类ids',
            'cate_path' => '路径',
            'created_at' => '创建时间',
            'updated_at' => '更新时间',
        ];
    }
}
