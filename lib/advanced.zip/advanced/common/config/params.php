<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'controller.aliasName' => 'Controller',
    'umask.controllerNames' => ['site','base'],
    'php.ext' => '.php',
    'action.prefix' => 'action',
];
