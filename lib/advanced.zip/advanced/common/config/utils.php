<?php

/**
 * 打印辅助函数
 * @param $arr
 */
function p($arr){
    echo "<pre>";
    if(is_string($arr)){
        echo $arr;
    }

    if(is_array($arr)){
        print_r($arr);
    }

    if (empty($arr)){
        var_dump($arr);
    }
    echo "</pre>";
}

/**
 * 根据字符串获取常量
 * @param $name
 * @return bool|mixed
 */
function d($name){
    if(defined($name)){
        return constant($name);
    }else{
        return false;
    }
}

function isFile($path){
    return is_file($path);
}

function isDir($path){
   return is_dir($path);
}

function echoLine($str){
    echo "$str\r\n";
}

/**
 * 获取类方法注释中的信息
 * @param $mark
 * @return mixed
 */
function getMarkInfo($mark){
    preg_match('/\[(.*?)\]/',$mark,$matches);
    if(empty($matches[1])){
        return false;
    }
    return $matches[1];
}

function debug(){

}

function info(){

}