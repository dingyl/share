$(function(){
    $(document).on('click','a.modal_action',function(){
        var self = $(this);
        var url = $(this).attr('href');
        $.get(url,function (resp) {
            if ( resp.redirect_url) {
                top.window.location.href = resp.redirect_url;
                return;
            }
            if ( resp.error_url) {
                top.window.location.href = resp.error_url;
                return;
            }
            var title = self.html();
            var html = '<div class="modal fade" id="normal_modal">' +
                '<div class="modal-dialog modal-lg">' +
                '<div class="modal-content">' +
                '<div class="modal-header">' +
                '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
                '<h4 class="modal-title">' + title + '</h4>' +
                '</div>' +

                '<div class="modal-body">' +
                resp +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>';

            $("#normal_modal").remove();
            $("body").append(html);
            $("#normal_modal").modal('show');

        });
        return false;
    })

    $('a.ajax_action').click(function (event) {
        event.preventDefault();
        var self = $(this);
        var url = self.attr("href");
        $.ajax({url: url}).done(function (resp) {
            if (resp.redirect_url) {
                top.window.location.href = resp.redirect_url;
                return;
            }
            if (resp.error_url) {
                top.window.location.href = resp.error_url;
                return;
            }

            if (0 != resp.error_code) {
                alert(resp.error_reason);
            } else {
                var model = self.parents("[data-model]").data('model');
                $.each(resp, function (k, v) {

                    $('#' + model + "_" + resp.id + "_" + k).html(v);
                });

                alert('操作成功');
            }
        });
    });
});