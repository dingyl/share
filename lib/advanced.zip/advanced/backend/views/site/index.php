<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
登陆成功