<?php
namespace backend\controllers;
use Yii;
use yii\web\Controller;
class BaseController extends Controller{

    public function beforeAction($action){
        if(parent::beforeAction($action)){
            return true;
        }
        return false;
    }

}