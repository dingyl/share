<?php
namespace backend\controllers;
use Yii;
/**
 * [角色管理员]
 * Class RoleController
 * @package backend\controllers
 */
class RoleController extends BaseController{

    /**
     * [角色列表]
     */
    public function actionIndex(){
        $auth = Yii::$app->authManager;
        $dataProvider = $auth->getRoles();
        $dataProvider1 = $auth->getPermissions();
        p($dataProvider);
        p($dataProvider1);die;
        $this->render('index',[
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * [添加角色]
     */
    public function actionNew(){

    }

    /**
     * [更新角色]
     */
    public function actionUpdate(){

    }


    /**
     * [删除角色]
     */
    public function actionDelete(){

    }
}