<?php
namespace console\controllers;

use Yii;
use yii\console\Controller;

class RbacController extends Controller
{
    //rbac初始化
    public function actionInit($module)
    {
        $this->initRbac($module);
    }

    //模块rbac初始化
    protected function initRbac($module){
        $controller_path =  Yii::getAlias("@$module/controllers");
        $auth = Yii::$app->authManager;
        $dh = opendir($controller_path);
        $controller_alias = Yii::$app->params['controller.aliasName'];
        $umask_controllers = Yii::$app->params['umask.controllerNames'];
        $action_prefix = Yii::$app->params['action.prefix'];
        $php_ext = Yii::$app->params['php.ext'];
        while($file = readdir($dh)) {
            $file_path = $controller_path . '/' . $file;
            if (isFile($file_path)) {
                $ctrl_name = str_replace($controller_alias . $php_ext, '', $file);
                if (!in_array(strtolower($ctrl_name), $umask_controllers)) {
                    $ctrl_full_name = $ctrl_name . $controller_alias;
                    $class_name = "\\$module\controllers\\" . $ctrl_full_name;
                    $reflect = new \ReflectionClass($class_name);
                    //获取控制器类的注释信息
                    $class_mark = $reflect->getDocComment();
                    $group_name = getMarkInfo($class_mark);
                    if ($group_name) {
                        foreach ($reflect->getMethods() as $method) {
                            $method_name = $method->getName();
                            $prefix = substr($method_name, 0, 6);
                            //过滤控制器方法
                            if ($prefix == $action_prefix && $method_name != 'actions') {
                                //获取方法的注释信息
                                $item_description = getMarkInfo($method->getDocComment());
                                if ($item_description) {
                                    $action_name = strtolower(substr($method_name, 6));
                                    $item_name = $ctrl_name . '-' . $action_name;
                                    if (!$auth->getPermission($item_name)) {
                                        $item = $auth->createPermission($item_name);
                                        $item->description = $item_description;
                                        $item->groupName = $group_name;
                                        $auth->add($item);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}