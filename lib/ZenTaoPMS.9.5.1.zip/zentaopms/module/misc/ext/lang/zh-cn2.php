<?php
$lang->misc->item2 = 'item2';
