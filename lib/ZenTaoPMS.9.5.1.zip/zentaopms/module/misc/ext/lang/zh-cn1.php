<?php
$lang->misc->item1 = 'item1';
