<?php
$lang->branch->common = '分支';
$lang->branch->manage = '分支管理';
$lang->branch->sort   = '排序';
$lang->branch->delete = '分支刪除';

$lang->branch->manageTitle = '%s管理';
$lang->branch->all         = '所有';

$lang->branch->id      = '編號';
$lang->branch->product = '所屬產品';
$lang->branch->name    = '名稱';
$lang->branch->order   = '排序';

$lang->branch->confirmDelete = '是否刪除該@branch@？';
$lang->branch->canNotDelete  = '該@branch@下已經有數據，不能刪除！';
