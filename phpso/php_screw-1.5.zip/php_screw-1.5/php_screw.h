#define PM9SCREW        "\tPM9SCREW\t"
#define PM9SCREW_LEN     10

char *zdecode(char *inbuf, int inbuf_len, int *resultbuf_len);
char *zencode(char *inbuf, int inbuf_len, int *resultbuf_len);
