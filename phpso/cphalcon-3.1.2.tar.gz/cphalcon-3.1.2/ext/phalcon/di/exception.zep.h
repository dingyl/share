
extern zend_class_entry *phalcon_di_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Di_Exception);

