Documentation
=============
Visit https://docs.phalconphp.com for a full documentation
